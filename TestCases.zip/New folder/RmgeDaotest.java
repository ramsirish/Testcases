package com.capegemini.irs.test;

import java.io.IOException;
import java.sql.Connection;
import java.util.List;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.capegemini.irs.bean.EmployeeBean;
import com.capegemini.irs.bean.RequisitionBean;
import com.capgemini.irs.dao.RmgeDao;
import com.capgemini.irs.dao.RmgeDaoImpl;
import com.capgemini.irs.util.DbUtility;

public class RmgeDaotest

{
	 Connection conn=null;
	 RmgeDao rmdao=null;
	 String rid=null;
	 RequisitionBean rbean=null;
	 String rbean1=null;
	 String rmid3=null;
	 String rmid4=null;

@Before
public void init() throws IOException
{
	 conn=DbUtility.getConnect();
}
@Test
public void checkDbConnectivity()
{
	
	 Assert.assertNotNull(conn);
}

@After
public void destroy()
{
	 conn=null;
}
@Before
public void init1()
{
	 rmdao=null;	
	 rid="rm01";
}
@Test
public void  getParticularRequisition() throws IOException
{
	RequisitionBean hai = new RequisitionBean();
	rmdao = new RmgeDaoImpl();
	hai=rmdao.getParticularRequisition("rm01");
	Assert.assertNotNull(hai);

}
@After
public void destroy1()
{
    rmdao=null;
}

@Before
public void init6()
{
	 rmdao=new RmgeDaoImpl();
	 rbean=new RequisitionBean("req02","rm01","p01","12-FEB-19","23-FEB-19","closed"," analyst"," level3","JEE",0);
	 		
}
@Test
public void getEmployeeDetails() throws IOException
{

	List<EmployeeBean> empList=rmdao.getEmployeeDetails(rbean);
	Assert.assertNotNull(empList);
}

@After
public void destroy6()
{
    rmdao=null;
}
@Before
public void init7()
{
	 rmdao=new RmgeDaoImpl();
	 rbean=new RequisitionBean("req01","rm01","p01","11-FEB-19","16-FEB-19","closed ","projectlead","level3","JEE",0);
	 	rmid3="rm01";	
}
@Test
public void getPendingRequisition() throws IOException
{

	List<RequisitionBean>  preqList=rmdao.getPendingRequisition(rmid3);
	Assert.assertNotNull(preqList);
}

@After
public void destroy7()
{
    rmdao=null;

}
@Before
public void init8()
{
	 rmdao=new RmgeDaoImpl();
	 rbean=new RequisitionBean("req02","rm01","p01","12-FEB-19","23-FEB-19","closed"," analyst"," level3","JEE",0);
	 	rmid4="rm01";	
}
@Test
public void getClosedRequisition() throws IOException
{

	List<RequisitionBean>  preqList=rmdao.getClosedRequisition(rmid4);
	Assert.assertNotNull(preqList);
}

@After
public void destroy8()
{
    rmdao=null;

}
}




